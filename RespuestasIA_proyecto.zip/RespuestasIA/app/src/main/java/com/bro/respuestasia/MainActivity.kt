package com.bro.respuestasia

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF1B1B22)
private val Red = Color(0xFFE53935)
private val TextMain = Color(0xFFF7F7FA)
private val Muted = Color(0xFFB5B5C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("respuestas_ia", Context.MODE_PRIVATE)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Bg,
                    surface = Panel,
                    onPrimary = Color.White,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                AppScreen(
                    initialEndpoint = prefs.getString("endpoint", "") ?: "",
                    onSaveEndpoint = { prefs.edit().putString("endpoint", it.trim()).apply() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppScreen(initialEndpoint: String, onSaveEndpoint: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val styles = listOf("Coqueto", "Romántico", "Con confianza", "Indirectas")
    var selectedStyle by remember { mutableStateOf(styles[0]) }
    var situation by remember { mutableStateOf("") }
    var endpoint by remember { mutableStateOf(initialEndpoint) }
    var response by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier.size(58.dp).background(Red, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("😍", fontSize = 29.sp) }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Respuestas IA", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = TextMain)
                    Text("Ideas nuevas para decirlo a tu manera", color = Muted, fontSize = 13.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "Cerrar" else "⚙", color = TextMain)
                }
            }

            if (showSettings) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Conexión con IA", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Pegá la URL HTTPS de tu servidor de IA. No pongas una clave secreta dentro de la app.", color = Muted, fontSize = 13.sp)
                        OutlinedTextField(
                            value = endpoint,
                            onValueChange = { endpoint = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("URL del servidor") },
                            placeholder = { Text("https://tu-servidor.com/api/generate") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Red,
                                unfocusedBorderColor = Muted,
                                focusedLabelColor = Red
                            )
                        )
                        Button(
                            onClick = {
                                onSaveEndpoint(endpoint)
                                showSettings = false
                                Toast.makeText(context, "URL guardada", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Red),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Guardar conexión") }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Elegí el estilo", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        styles.chunked(2).forEach { rowStyles ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowStyles.forEach { style ->
                                    val chosen = selectedStyle == style
                                    FilterChip(
                                        selected = chosen,
                                        onClick = { selectedStyle = style },
                                        label = { Text(style) },
                                        modifier = Modifier.weight(1f),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Red,
                                            selectedLabelColor = Color.White,
                                            labelColor = TextMain
                                        )
                                    )
                                }
                                if (rowStyles.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    OutlinedTextField(
                        value = situation,
                        onValueChange = { situation = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("¿Qué querés responder?") },
                        placeholder = { Text("Ej.: me dijo que me extraña, ¿qué le contesto?") },
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Red,
                            unfocusedBorderColor = Muted,
                            focusedLabelColor = Red
                        )
                    )
                    Button(
                        onClick = {
                            if (situation.isBlank()) {
                                error = "Escribí la situación primero."
                            } else if (endpoint.isBlank()) {
                                error = "Falta conectar el servidor de IA. Abrí ⚙ y pegá su URL."
                                showSettings = true
                            } else {
                                error = ""
                                busy = true
                                response = ""
                                val prompt = situation.trim()
                                val chosenStyle = selectedStyle
                                val url = endpoint.trim()
                                scope.launch {
                                    try {
                                        response = withContext(Dispatchers.IO) { requestAnswer(url, chosenStyle, prompt) }
                                    } catch (e: Exception) {
                                        error = "No se pudo conectar. Revisá la URL y que el servidor esté funcionando. Detalle: ${e.message ?: "error de red"}"
                                    } finally {
                                        busy = false
                                    }
                                }
                            }
                        },
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Red.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (busy) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Pensando…")
                        } else {
                            Text("✨ Generar respuesta", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
                }
            }

            if (response.isNotBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Tu respuesta", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(response, fontSize = 16.sp, lineHeight = 24.sp, color = TextMain)
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Respuesta IA", response))
                                Toast.makeText(context, "Respuesta copiada", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF33333D)),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Copiar respuesta") }
                    }
                }
            }
            Text("Gratis con límites del proveedor de IA. Requiere conexión a internet.", color = Muted, fontSize = 12.sp)
        }
    }
}

private fun requestAnswer(endpoint: String, style: String, situation: String): String {
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 30000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    try {
        val body = JSONObject()
            .put("style", style)
            .put("situation", situation)
            .toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IllegalStateException("Servidor respondió HTTP $code: ${text.take(180)}")
        val json = JSONObject(text)
        return json.optString("text").ifBlank { "El servidor respondió, pero no envió el texto esperado." }
    } finally {
        connection.disconnect()
    }
}

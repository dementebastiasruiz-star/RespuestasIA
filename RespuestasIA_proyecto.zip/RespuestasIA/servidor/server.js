const express = require("express");

const app = express();
app.use(express.json({ limit: "12kb" }));

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.get("/", (_req, res) => res.json({ status: "ok", service: "Respuestas IA" }));

app.post("/api/generate", async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(503).json({ error: "Falta configurar GEMINI_API_KEY en el servidor." });
    }
    const style = String(req.body?.style || "").slice(0, 40);
    const situation = String(req.body?.situation || "").trim().slice(0, 2000);
    const allowed = ["Coqueto", "Romántico", "Con confianza", "Indirectas"];
    if (!allowed.includes(style) || !situation) {
      return res.status(400).json({ error: "Indicá un estilo válido y una situación." });
    }

    const instructions = {
      "Coqueto": "Usá un tono coqueto, simpático y respetuoso, sin ser explícito.",
      "Romántico": "Usá un tono romántico, cálido y sincero, sin exagerar.",
      "Con confianza": "Usá un tono seguro, natural y directo, sin ser agresivo.",
      "Indirectas": "Creá una indirecta sutil, ingeniosa y respetuosa, sin humillar."
    };

    const prompt = [
      "Sos un asistente que ayuda a redactar respuestas breves en español rioplatense natural.",
      "Generá una respuesta ORIGINAL adaptada al contexto; no uses una plantilla fija ni repitas siempre la misma frase.",
      instructions[style],
      "Devolvé solamente el texto sugerido, sin comillas ni explicaciones. Si falta contexto, hacé una propuesta prudente.",
      "Situación del usuario: " + situation
    ].join("\n");

    const apiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(API_KEY)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.9, maxOutputTokens: 220 }
        })
      }
    );

    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      console.error("Gemini API error:", apiResponse.status, JSON.stringify(data).slice(0, 500));
      return res.status(502).json({ error: "El proveedor de IA rechazó la solicitud. Revisá la clave, el modelo y la cuota." });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "")
      .join("")
      .trim();

    if (!answer) return res.status(502).json({ error: "La IA no devolvió una respuesta." });
    res.json({ text: answer });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error interno del servidor." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Respuestas IA escuchando en el puerto ${PORT}`);
});

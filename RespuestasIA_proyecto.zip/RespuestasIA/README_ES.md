# Respuestas IA — proyecto Android

Proyecto inicial de Android para una app oscura con perfil 😍 sobre fondo rojo y cuatro estilos: Coqueto, Romántico, Con confianza e Indirectas.

## Qué incluye

- Aplicación Android nativa hecha con Kotlin y Jetpack Compose.
- Campo para describir la situación y generar respuestas nuevas con IA.
- Botón para copiar la respuesta.
- Configuración para pegar la URL del servidor.
- Servidor Node.js que mantiene la clave de IA fuera del APK.

## Importante

El APK por sí solo no genera respuestas de IA: necesita internet y un servidor configurado. La app **no contiene una clave secreta**. No pegues claves privadas en el código Android ni compartas el APK con una clave dentro.

El servidor de ejemplo usa la API de Gemini. La disponibilidad de cuota gratuita, los modelos y las condiciones pueden cambiar según la cuenta y la región; revisalos en la documentación oficial de Google AI Studio. Una cuota gratuita no significa uso ilimitado.

## A. Crear una clave para el servidor

1. En una computadora, entrá a Google AI Studio: https://aistudio.google.com/
2. Iniciá sesión y creá una API key si tu cuenta tiene acceso.
3. Guardala en un lugar privado. No la mandes por chat ni la pongas en la app Android.

## B. Poner en marcha el servidor

Necesitás una computadora o servicio de hosting que pueda ejecutar Node.js 18 o posterior.

1. Instalá Node.js 18+.
2. Abrí una terminal dentro de la carpeta `servidor`.
3. Ejecutá `npm install`.
4. Configurá la variable de entorno `GEMINI_API_KEY` con tu clave secreta.
   - Windows PowerShell (solo para la ventana actual): `$env:GEMINI_API_KEY="TU_CLAVE"`
   - macOS/Linux: `export GEMINI_API_KEY="TU_CLAVE"`
5. Ejecutá `npm start`.
6. Probá en el navegador `http://IP-DE-TU-PC:3000/` si la app y el servidor están en la misma red.

Para usarla desde el teléfono fuera de tu Wi-Fi, publicá el servidor en un hosting con HTTPS. No expongas directamente un servidor local a internet sin seguridad, límites de uso y protección contra abuso.

## C. Abrir y compilar el APK

1. Instalá Android Studio en una computadora: https://developer.android.com/studio
2. Descomprimí el ZIP.
3. En Android Studio elegí **Open** y seleccioná la carpeta `RespuestasIA` (la que contiene `settings.gradle.kts`).
4. Esperá a que termine **Gradle Sync**. Si te pide instalar Android SDK 35 o herramientas de compilación, aceptá.
5. En el menú elegí **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Cuando termine, pulsá el enlace **locate** que aparece en la notificación.
7. El APK de depuración debería estar en `app/build/outputs/apk/debug/app-debug.apk`.

## D. Instalarlo en tu Moto G24

1. Pasá `app-debug.apk` al Moto G24 (USB, Drive o un método de confianza).
2. Abrí el archivo desde el teléfono.
3. Si Android lo solicita, permití instalar aplicaciones de esa fuente solo para la app desde la que abriste el archivo.
4. Tocá **Instalar**. Instalá APK únicamente si confiás en su origen.

## E. Conectar la app al servidor

1. Abrí Respuestas IA.
2. Tocá el botón ⚙.
3. Pegá la dirección completa del endpoint, por ejemplo `https://tu-servidor.example/api/generate`.
4. Guardá la conexión y probá una situación.

La URL de ejemplo no es un servidor real: reemplazala por la URL HTTPS que te dé tu hosting. Si ejecutás el servidor solo en tu PC, usá la IP local de la computadora y el puerto 3000, con ambos dispositivos conectados a la misma Wi-Fi. Para pruebas locales, Android permite HTTP en esta versión del proyecto, pero para uso real preferí HTTPS.

## Solución de problemas

- **No aparece el APK:** esperá a que finalice el proceso Build APK(s); revisá la pestaña Build.
- **Gradle falla:** comprobá internet, Android SDK 35 y que Android Studio esté actualizado.
- **No conecta:** verificá la URL completa, que termine en `/api/generate`, y que el servidor esté en ejecución.
- **Error 503:** falta configurar `GEMINI_API_KEY` en el servidor.
- **Error 502/cuota:** revisá la clave, el modelo habilitado y los límites de tu proveedor.

## Límites de esta versión

Es un proyecto inicial funcional, no una app ya publicada ni un APK ya compilado. Requiere una computadora para compilarlo con Android Studio y un servidor para la IA. La interfaz no usa plantillas fijas para las respuestas generadas.
